package com.entry;

import java.util.Objects;

public class StudentDao{
	String name;
	String city;
	int roll;
	String email;
	public StudentDao(String name, String city, int roll, String email) {
		super();
		this.name = name;
		this.city = city;
		this.roll = roll;
		this.email = email;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getRoll() {
		return roll;
	}

	public void setRoll(int roll) {
		this.roll = roll;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, roll);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentDao other = (StudentDao) obj;
		return Objects.equals(name, other.name) && roll == other.roll;
	}

	@Override
	public String toString() {
		return "StudentDao [name=" + name + ", city=" + city + ", roll=" + roll + ", email=" + email + "]";
	}
	
	
	

}
