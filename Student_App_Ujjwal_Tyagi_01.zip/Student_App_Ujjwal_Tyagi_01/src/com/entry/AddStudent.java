package com.entry;
import java.util.*;

public class AddStudent{
		public static Set<StudentDao> set=new HashSet<StudentDao>();
}
