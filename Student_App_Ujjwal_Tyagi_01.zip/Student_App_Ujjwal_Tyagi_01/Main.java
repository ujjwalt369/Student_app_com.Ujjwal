package com.entry;
import java.util.*;
public class Main {
	public static void mainMenu() throws InputMismatchException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enetr Your Choice\n1.Add Student\n2.Update Student\n3.Display All\n4.Delete Student\n5.Get Student By Roll No.\n6.Exit\n..............-----------.............");
	    int choice =sc.nextInt();
	    
	    switch (choice) {
		case 1: {
			System.out.println("Enter name: ");
			String name=sc.next();
			sc.nextLine();
			System.out.println("Enter city: ");
			String city=sc.nextLine();
			System.out.println("Enter email: ");
			String email=sc.nextLine();
			System.out.println("Enter Roll No.");
			int roll=sc.nextInt();
			StudentDao stu=new StudentDao(name,city,roll,email);
			if(!(AddStudent.set.contains(stu))) {
				AddStudent.set.add(stu);
			}else {
				System.out.println("Sorry Student at roll no. already exists!");
			}
			break;
		}
		case 2: {
			System.out.println("Please Enter The Roll No. of Student to be Updated: ");
			int uprollno=sc.nextInt();
			for(StudentDao temp:AddStudent.set) {
				if(temp.getRoll()==uprollno) {
					System.out.println(temp);
					System.out.println("Enter fields to be updated\n1.Name\n2.Email-Id\n3.City");
					int tc=sc.nextInt();
					switch (tc) {
					case 1: {
						System.out.println("Enter New Name");
						sc.nextLine();
						String tn=sc.nextLine();
						temp.setName(tn);
						break;
					}
					case 2: {
						System.out.println("Enter New Email-Id");
						sc.nextLine();
						String te=sc.nextLine();
						temp.setEmail(te);
						break;
					}
					case 3: {
						System.out.println("Enter New city");
						sc.nextLine();
						String tcity=sc.nextLine();
						temp.setCity(tcity);
						break;
					}
					default:
						throw new IllegalArgumentException("Unexpected value: " + tc);
					}
					
				}
			}
			break;
		}
		case 3: {
			for(StudentDao show:AddStudent.set) {
				System.out.println(show);
				System.out.println("-_-_-_-_-_-_-_-_-_-_");
			}
		break;
		}
		case 4: {
			System.out.println("Please Enter The Roll No. of Student to be Deleted: ");
			int delrollno=sc.nextInt();
			for(StudentDao temp1:AddStudent.set) {
				if(temp1.getRoll()==delrollno){
					AddStudent.set.remove(temp1);
					break;
				}
				}
			System.out.println("Student Deleted Successfully!");
			break;
		}
		case 5: {
			System.out.println("Please Enter The Roll No. of Student to be Displayed: ");
			int showrollno=sc.nextInt();
			for(StudentDao temp2:AddStudent.set) {
				if(temp2.getRoll()==showrollno) {
					System.out.println(temp2);
					break;
				}
			}
			break;
		}
		case 6: {
	        System.exit(0);
	        break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choice);
		}
	    
	    System.out.println("Do Yo Still Want to Continue?Yes(Y)/No(N)");
	    Scanner scn=new Scanner(System.in);
		String cont=scn.nextLine();
		if(cont.equalsIgnoreCase("Y")) {
			mainMenu();
		}
	}

	public static void main(String[] args) throws InputMismatchException{
			mainMenu();
	}

}
